/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  68
 *  java.lang.MatchException
 */
package dev.krypton;

import dev.krypton._32;
import dev.krypton._6i_0;
import dev.krypton.l;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class _8W
extends _8d {
    final _6i_0 cfr_renamed_9;
    private static final long a = l.a(2450525739855979711L, -5332935945357223029L, MethodHandles.lookup().lookupClass()).a(149466952952883L);
    private static final long b;
    private static final Object[] c;
    private static final String[] d;

    _8W(_6i_0 i_0) {
        this.cfr_renamed_9 = i_0;
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        c = new Object[11];
        d = new String[11];
        _8W.a();
        long l2 = a ^ 0x23D24B714F0CL;
        Cipher cipher = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l2 >>> 56);
        int n = 1;
        while (true) {
            if (n >= 8) {
                cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
                long l3 = -704744967554074509L;
                byte[] byArray3 = cipher.doFinal(new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3});
                b = ((long)byArray3[0] & 0xFFL) << 56 | ((long)byArray3[1] & 0xFFL) << 48 | ((long)byArray3[2] & 0xFFL) << 40 | ((long)byArray3[3] & 0xFFL) << 32 | ((long)byArray3[4] & 0xFFL) << 24 | ((long)byArray3[5] & 0xFFL) << 16 | ((long)byArray3[6] & 0xFFL) << 8 | (long)byArray3[7] & 0xFFL;
                return;
            }
            byArray2 = byArray2;
            byArray2[n] = (byte)(l2 << n * 8 >>> 56);
            ++n;
        }
    }

    private static Method b(Class clazz, String string, Class clazz2, int n, Class[] classArray) {
        Method method = _8W.a(clazz, string, clazz2, n, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int j = 0; j < classArray2.length; ++j) {
                method = _8W.b(classArray2[j], string, clazz2, n, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Field b(Class clazz, String string, Class clazz2) {
        Field field = _8W.a(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int j = 0; j < classArray.length; ++j) {
                field = _8W.b(classArray[j], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Class b(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n = _8W.a(l2, l3);
            object = c[n];
            try {
                if (!(object instanceof String)) break block2;
                _8W.c[n] = clazz = Class.forName(d[n]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field c(long l2, long l3) {
        int n = _8W.a(l2, l3);
        Object object = c[n];
        if (object instanceof String) {
            String string = d[n];
            int n2 = string.indexOf(8);
            Class clazz = _8W.b(Long.parseLong(string.substring(0, n2), 36), 0L);
            int n3 = string.indexOf(8, ++n2);
            String string2 = string.substring(n2, n3);
            Class clazz2 = _8W.b(Long.parseLong(string.substring(++n3), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = _8W.a(clazz3, string2, clazz2)) != null) {
                    _8W.c[n] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int j = 0; j < classArray.length; ++j) {
                        field = _8W.b(classArray[j], string2, clazz2);
                        if (field == null) continue;
                        _8W.c[n] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = _8W.b(489148580605346L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method d(long l2, long l3) {
        int n = _8W.a(l2, l3);
        Object object = c[n];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n2;
            String string;
            Class clazz3;
            block10: {
                String string2 = d[n];
                int n3 = string2.indexOf(8);
                clazz3 = _8W.b(Long.parseLong(string2.substring(0, n3), 36), 0L);
                int n4 = string2.indexOf(8, ++n3);
                string = string2.substring(n3, n4);
                int n5 = -1;
                int n6 = n4;
                do {
                    ++n5;
                    ++n6;
                } while ((n6 = string2.indexOf(8, n6)) > -1);
                n2 = n5 - 1;
                classArray2 = new Class[n2];
                clazz2 = null;
                n6 = n4 + 1;
                for (int j = 0; j < n5; ++j) {
                    int n7 = string2.indexOf(8, n6);
                    clazz2 = _8W.b(Long.parseLong(string2.substring(n6, n7), 36), 0L);
                    if (j < n2) {
                        classArray2[j] = clazz2;
                    }
                    n6 = n7 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = _8W.a(clazz, string, clazz2, n2, classArray2)) != null) {
                        _8W.c[n] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = _8W.b(489148580605346L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int j = 0; j < classArray.length; ++j) {
                        Method method = _8W.b(classArray[j], string, clazz2, n2, classArray2);
                        if (method == null) continue;
                        _8W.c[n] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = _8W.b(489148580605346L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n8 = 0;
            while (n8 < n2) {
                stringBuffer.append(classArray2[n8].getName());
                if (++n8 >= n2) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static Method a(Class clazz, String string, Class clazz2, int n, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n) continue;
            for (int j = 0; j < n; ++j) {
                if (classArray2[j] != classArray[j]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static CallSite a(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("dev/krypton/8W" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static MethodHandle a(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c == '\u00ed' || c == '\u00f8' || c == 'e' || c == 'm') {
                field = _8W.c(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c == '\u00ed' ? lookup.findGetter(clazz, string2, clazz2) : (c == '\u00f8' ? lookup.findSetter(clazz, string2, clazz2) : (c == 'e' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = _8W.d(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c == '\u00ff' ? lookup.findVirtual(clazz, string3, methodType2) : (c == '\u00cd' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, Long.TYPE, Long.TYPE);
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object a(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n = objectArray.length - 2;
        long l2 = (Long)objectArray[n];
        long l3 = (Long)objectArray[++n];
        MethodHandle methodHandle = _8W.a(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static int a(long l2, long l3) {
        int n;
        int n2;
        int n3 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (d[n3] != null) {
            return n3;
        }
        Object object = c[n3];
        if (!(object instanceof String)) {
            return n3;
        }
        int n4 = 0;
        n4 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 9;
            case 1 -> 7;
            case 2 -> 55;
            case 3 -> 12;
            case 4 -> 32;
            case 5 -> 27;
            case 6 -> 13;
            case 7 -> 10;
            case 8 -> 24;
            case 9 -> 2;
            case 10 -> 44;
            case 11 -> 0;
            case 12 -> 17;
            case 13 -> 52;
            case 14 -> 26;
            case 15 -> 62;
            case 16 -> 42;
            case 17 -> 54;
            case 18 -> 14;
            case 19 -> 43;
            case 20 -> 56;
            case 21 -> 47;
            case 22 -> 38;
            case 23 -> 57;
            case 24 -> 25;
            case 25 -> 35;
            case 26 -> 19;
            case 27 -> 49;
            case 28 -> 51;
            case 29 -> 5;
            case 30 -> 58;
            case 31 -> 60;
            case 32 -> 29;
            case 33 -> 11;
            case 34 -> 61;
            case 35 -> 3;
            case 36 -> 30;
            case 37 -> 40;
            case 38 -> 36;
            case 39 -> 48;
            case 40 -> 20;
            case 41 -> 46;
            case 42 -> 33;
            case 43 -> 39;
            case 44 -> 59;
            case 45 -> 16;
            case 46 -> 34;
            case 47 -> 37;
            case 48 -> 41;
            case 49 -> 1;
            case 50 -> 28;
            case 51 -> 23;
            case 52 -> 18;
            case 53 -> 53;
            case 54 -> 4;
            case 55 -> 22;
            case 56 -> 6;
            case 57 -> 31;
            case 58 -> 50;
            case 59 -> 45;
            case 60 -> 63;
            case 61 -> 15;
            case 62 -> 8;
            default -> 21;
        };
        int[] nArray = new int[6];
        int n5 = 0;
        while (n5 < 6) {
            n2 = 7 * (5 - n5);
            n = (int)(l2 >>> n2 & 0x7FL);
            if ((n -= n4) < 0) {
                n += 128;
            }
            nArray[n5] = n;
            ++n5;
        }
        char[] cArray = ((String)object).toCharArray();
        n2 = 0;
        while (n2 < cArray.length) {
            n = nArray[n2 % nArray.length];
            if (n == 0) break;
            cArray[n2] = (char)(cArray[n2] ^ n);
            ++n2;
        }
        _8W.d[n3] = new String(cArray);
        return n3;
    }

    private static void a() {
        Object[] objectArray = c;
        c[0] = "9\u0014m5E\u0011$\u0001ot@Me&";
        objectArray[1] = "tKl\reoi^nL`3&G";
        objectArray[2] = Boolean.TYPE;
        _8W.d[2] = "java/lang/Boolean";
        objectArray[3] = "\u001dT.EAcht%JP,\tz.ATv}";
        objectArray[4] = Void.TYPE;
        _8W.d[4] = "java/lang/Void";
        objectArray[5] = "\u0000\u0012\u001b\u001b+v\u001d\u0007\u0019Z.*R\u000f";
        objectArray[6] = "\u001d\u0006`\b\u0018\u0011\u0016\tqGy\u001f\u001d\u0002u\u001d";
        objectArray[7] = "\n<@\r}\"\u00030Mv=ZH(M\u001dl?\u0010+IM";
        objectArray[8] = " cT#\u001b_gcAZM<av[!\u000fDhzV";
        objectArray[9] = "F$] 6@O(P[q}=p_`+G_,S238\u0006s\u000e+qY\u0000rCjK";
        Object[] objectArray2 = objectArray;
        objectArray[10] = "\u001fKTS\u0013\u0018DCM@-X$\u0013J_F\u0005AKI[\u0016i";
    }

    private static MatchException a(MatchException matchException) {
        return matchException;
    }

    private static Field a(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    @Override
    public void cfr_renamed_7(_68 var1_1) {
        block12: {
            Object object;
            long l2;
            long l3;
            block13: {
                int n;
                block11: {
                    l3 = a ^ 0x49AB11FFADC1L;
                    l2 = l3 ^ 0x3B456A70A4EAL;
                    n = _32.cfr_renamed_2();
                    try {
                        try {
                            object = _8W.a("\u00ed", (Object)_8W.a("\u00ed", (Object)this, -7792508654518468423L, (long)l3), -7793309513698555102L, (long)l3);
                            if (n == 0) break block11;
                            if (object != false) break block12;
                        }
                        catch (MatchException matchException) {
                            throw _8W.a(matchException);
                        }
                        object = _8W.a("\u00ff", (Object)_8W.a("\u00ed", (Object)this, -7792508654518468423L, (long)l3), -7792389662191154251L, (long)l3);
                    }
                    catch (MatchException matchException) {
                        throw _8W.a(matchException);
                    }
                }
                try {
                    try {
                        if (n == 0) break block13;
                        if (object == false) break block12;
                    }
                    catch (MatchException matchException) {
                        throw _8W.a(matchException);
                    }
                    object = var1_1.cfr_renamed_0();
                }
                catch (MatchException matchException) {
                    throw _8W.a(matchException);
                }
            }
            try {
                if (object == (int)b) {
                    Object[] objectArray = new Object[1];
                    objectArray[0] = l2;
                    _8W.a("\u00ff", (Object)_8W.a("\u00ed", (Object)this, -7792508654518468423L, (long)l3), (Object)objectArray, -7792606523879463677L, (long)l3);
                }
            }
            catch (MatchException matchException) {
                throw _8W.a(matchException);
            }
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(_8W.class, "a", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

