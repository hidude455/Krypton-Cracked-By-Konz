/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  java.lang.MatchException
 *  net.minecraft.class_1657
 *  net.minecraft.class_465
 */
package dev.krypton;

import dev.krypton._3i_0;
import dev.krypton._3s;
import dev.krypton._4r;
import dev.krypton._4w;
import dev.krypton._6x_0;
import dev.krypton._9o;
import dev.krypton.l;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.class_1657;
import net.minecraft.class_465;

public class _67
extends _6x_0 {
    private static final long b = l.a(-8975317457882034352L, 7365251822390490257L, MethodHandles.lookup().lookupClass()).a(73189269120788L);
    private static final long[] d;
    private static final Integer[] e;
    private static final Map f;
    private static final Object[] j;
    private static final String[] k;

    @_3i_0
    public void cfr_renamed_5(_9o o) {
        block41: {
            CallSite callSite;
            long l2;
            block50: {
                Object object;
                block49: {
                    reference v15;
                    _4w[] wArray;
                    block48: {
                        block47: {
                            block46: {
                                block45: {
                                    block44: {
                                        block43: {
                                            block42: {
                                                block40: {
                                                    l2 = b ^ 0x16222037FCCEL;
                                                    wArray = _3s.cfr_renamed_5();
                                                    try {
                                                        try {
                                                            object = _67.c("\u00f5", (Object)_67.c("\u00f5", (Object)this, -8963888802061883324L, (long)l2), -8964053444191562977L, (long)l2) instanceof class_465;
                                                            if (wArray != null) break block40;
                                                            if (object != false) break block41;
                                                        }
                                                        catch (MatchException matchException) {
                                                            throw _67.a(matchException);
                                                        }
                                                        object = _67.c("z", (Object)_67.c("\u00f5", (Object)_67.c("\u00f5", (Object)this, -8963888802061883324L, (long)l2), -8964091740113249182L, (long)l2), -8963967773444065939L, (long)l2);
                                                    }
                                                    catch (MatchException matchException) {
                                                        throw _67.a(matchException);
                                                    }
                                                }
                                                try {
                                                    try {
                                                        if (wArray != null) break block42;
                                                        if (object != false) break block41;
                                                    }
                                                    catch (MatchException matchException) {
                                                        throw _67.a(matchException);
                                                    }
                                                    object = _67.c("z", (Object)_67.c("\u00f5", (Object)_67.c("\u00f5", (Object)this, -8963888802061883324L, (long)l2), -8964091740113249182L, (long)l2), -8962573224495274211L, (long)l2);
                                                }
                                                catch (MatchException matchException) {
                                                    throw _67.a(matchException);
                                                }
                                            }
                                            try {
                                                try {
                                                    if (wArray != null) break block43;
                                                    if (object != false) break block41;
                                                }
                                                catch (MatchException matchException) {
                                                    throw _67.a(matchException);
                                                }
                                                object = _67.c("z", (Object)_67.c("\u00f5", (Object)_67.c("\u00f5", (Object)this, -8963888802061883324L, (long)l2), -8964091740113249182L, (long)l2), -8962301234552620435L, (long)l2);
                                            }
                                            catch (MatchException matchException) {
                                                throw _67.a(matchException);
                                            }
                                        }
                                        try {
                                            try {
                                                if (wArray != null) break block44;
                                                if (object != false) break block41;
                                            }
                                            catch (MatchException matchException) {
                                                throw _67.a(matchException);
                                            }
                                            object = _67.c("z", (Object)_67.c("\u00f5", (Object)_67.c("\u00f5", (Object)this, -8963888802061883324L, (long)l2), -8964091740113249182L, (long)l2), -8964245380635284981L, (long)l2) instanceof class_1657;
                                        }
                                        catch (MatchException matchException) {
                                            throw _67.a(matchException);
                                        }
                                    }
                                    try {
                                        try {
                                            if (wArray != null) break block45;
                                            if (object == false) break block41;
                                        }
                                        catch (MatchException matchException) {
                                            throw _67.a(matchException);
                                        }
                                        object = _67.c("z", (Object)_67.c("z", (Object)_67.c("\u00f5", (Object)_67.c("\u00f5", (Object)this, -8963888802061883324L, (long)l2), -8964091740113249182L, (long)l2), -8964245380635284981L, (long)l2), -8962588425842341618L, (long)l2);
                                    }
                                    catch (MatchException matchException) {
                                        throw _67.a(matchException);
                                    }
                                }
                                try {
                                    try {
                                        if (wArray != null) break block46;
                                        if (object == false) break block41;
                                    }
                                    catch (MatchException matchException) {
                                        throw _67.a(matchException);
                                    }
                                    object = _67.c("\u00f5", (Object)_67.c("z", (Object)_67.c("\u00f5", (Object)_67.c("\u00f5", (Object)this, -8963888802061883324L, (long)l2), -8964091740113249182L, (long)l2), -8964245380635284981L, (long)l2), -8962417878188802920L, (long)l2);
                                }
                                catch (MatchException matchException) {
                                    throw _67.a(matchException);
                                }
                            }
                            try {
                                try {
                                    if (wArray != null) break block47;
                                    if (object <= 0) break block41;
                                }
                                catch (MatchException matchException) {
                                    throw _67.a(matchException);
                                }
                                object = _67.c("\u00f5", (Object)_67.c("z", (Object)_67.c("\u00f5", (Object)_67.c("\u00f5", (Object)this, -8963888802061883324L, (long)l2), -8964091740113249182L, (long)l2), -8964245380635284981L, (long)l2), -8962417878188802920L, (long)l2);
                            }
                            catch (MatchException matchException) {
                                throw _67.a(matchException);
                            }
                        }
                        try {
                            try {
                                try {
                                    v15 = _67.a("o", 3472, (long)(0x5320E6264B92069DL ^ l2));
                                    if (wArray != null) break block48;
                                    if (object >= v15) break block41;
                                }
                                catch (MatchException matchException) {
                                    throw _67.a(matchException);
                                }
                                object = _67.c("\u00f5", (Object)_67.c("z", (Object)_67.c("\u00f5", (Object)_67.c("\u00f5", (Object)this, -8963888802061883324L, (long)l2), -8964091740113249182L, (long)l2), -8964245380635284981L, (long)l2), -8962417878188802920L, (long)l2);
                                if (wArray != null) break block49;
                            }
                            catch (MatchException matchException) {
                                throw _67.a(matchException);
                            }
                            v15 = _67.c("\u00f5", (Object)_67.c("z", (Object)_67.c("\u00f5", (Object)_67.c("\u00f5", (Object)this, -8963888802061883324L, (long)l2), -8964091740113249182L, (long)l2), -8964245380635284981L, (long)l2), -8962312830394807009L, (long)l2) - true;
                        }
                        catch (MatchException matchException) {
                            throw _67.a(matchException);
                        }
                    }
                    try {
                        try {
                            if (object != v15) break block41;
                            callSite = _67.c("\u00f5", (Object)_67.c("\u00f5", (Object)this, -8963888802061883324L, (long)l2), -8964091740113249182L, (long)l2);
                            if (wArray != null) break block50;
                        }
                        catch (MatchException matchException) {
                            throw _67.a(matchException);
                        }
                        object = _67.c("z", (Object)_67.c("z", (Object)callSite, -8964245380635284981L, (long)l2), -8962674073511158157L, (long)l2);
                    }
                    catch (MatchException matchException) {
                        throw _67.a(matchException);
                    }
                }
                try {
                    if (object != 0) break block41;
                    callSite = _67.c("\u00f5", (Object)_67.c("\u00f5", (Object)this, -8963888802061883324L, (long)l2), -8964091740113249182L, (long)l2);
                }
                catch (MatchException matchException) {
                    throw _67.a(matchException);
                }
            }
            _67.c("z", (Object)callSite, -8964154753109806865L, (long)l2);
        }
    }

    public _67(long l2) {
        long l3 = (l2 = b ^ l2) ^ 0x36EE199A1A31L;
        super((int)_67.a("o", 630, (long)(0x63F1E62EA8C2B9FAL ^ l2)), -1, (_4r)((Object)_67.c("\u00cf", -5539720545539215209L, (long)l2)), l3);
    }

    /*
     * Enabled aggressive block sorting
     */
    static {
        j = new Object[23];
        k = new String[23];
        _67.b();
        f = new HashMap(13);
        long l2 = b ^ 0x3E3F42D7AD0FL;
        Cipher cipher = Cipher.getInstance("DES/CBC/NoPadding");
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DES");
        byte[] byArray = new byte[8];
        byte[] byArray2 = byArray;
        byArray[0] = (byte)(l2 >>> 56);
        for (int j = 1; j < 8; ++j) {
            byArray2 = byArray2;
            byArray2[j] = (byte)(l2 << j * 8 >>> 56);
        }
        cipher.init(2, (Key)secretKeyFactory.generateSecret(new DESKeySpec(byArray2)), new IvParameterSpec(new byte[8]));
        long[] lArray = new long[2];
        int n = 0;
        String string = "\u0091p0\u00b3\u00a2\u0007\u00f8p\u00c9$e]h`k?";
        int n2 = "\u0091p0\u00b3\u00a2\u0007\u00f8p\u00c9$e]h`k?".length();
        int n3 = 0;
        do {
            byte[] byArray3 = string.substring(n3, n3 += 8).getBytes("ISO-8859-1");
            int n4 = n++;
            long l3 = ((long)byArray3[0] & 0xFFL) << 56 | ((long)byArray3[1] & 0xFFL) << 48 | ((long)byArray3[2] & 0xFFL) << 40 | ((long)byArray3[3] & 0xFFL) << 32 | ((long)byArray3[4] & 0xFFL) << 24 | ((long)byArray3[5] & 0xFFL) << 16 | ((long)byArray3[6] & 0xFFL) << 8 | (long)byArray3[7] & 0xFFL;
            byte[] byArray4 = cipher.doFinal(new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3});
            lArray[n4] = ((long)byArray4[0] & 0xFFL) << 56 | ((long)byArray4[1] & 0xFFL) << 48 | ((long)byArray4[2] & 0xFFL) << 40 | ((long)byArray4[3] & 0xFFL) << 32 | ((long)byArray4[4] & 0xFFL) << 24 | ((long)byArray4[5] & 0xFFL) << 16 | ((long)byArray4[6] & 0xFFL) << 8 | (long)byArray4[7] & 0xFFL;
        } while (n3 < n2);
        d = lArray;
        e = new Integer[2];
    }

    private static int e(long l2, long l3) {
        int n;
        int n2;
        int n3 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (k[n3] != null) {
            return n3;
        }
        Object object = j[n3];
        if (!(object instanceof String)) {
            return n3;
        }
        int n4 = 0;
        n4 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 56;
            case 1 -> 3;
            case 2 -> 42;
            case 3 -> 61;
            case 4 -> 17;
            case 5 -> 49;
            case 6 -> 34;
            case 7 -> 10;
            case 8 -> 5;
            case 9 -> 26;
            case 10 -> 32;
            case 11 -> 0;
            case 12 -> 23;
            case 13 -> 20;
            case 14 -> 52;
            case 15 -> 46;
            case 16 -> 39;
            case 17 -> 50;
            case 18 -> 41;
            case 19 -> 22;
            case 20 -> 55;
            case 21 -> 14;
            case 22 -> 11;
            case 23 -> 13;
            case 24 -> 25;
            case 25 -> 19;
            case 26 -> 47;
            case 27 -> 54;
            case 28 -> 2;
            case 29 -> 4;
            case 30 -> 37;
            case 31 -> 63;
            case 32 -> 15;
            case 33 -> 35;
            case 34 -> 60;
            case 35 -> 45;
            case 36 -> 51;
            case 37 -> 8;
            case 38 -> 7;
            case 39 -> 48;
            case 40 -> 58;
            case 41 -> 1;
            case 42 -> 33;
            case 43 -> 21;
            case 44 -> 40;
            case 45 -> 27;
            case 46 -> 24;
            case 47 -> 6;
            case 48 -> 12;
            case 49 -> 62;
            case 50 -> 28;
            case 51 -> 57;
            case 52 -> 36;
            case 53 -> 44;
            case 54 -> 31;
            case 55 -> 9;
            case 56 -> 59;
            case 57 -> 18;
            case 58 -> 53;
            case 59 -> 29;
            case 60 -> 30;
            case 61 -> 38;
            case 62 -> 16;
            default -> 43;
        };
        int[] nArray = new int[6];
        int n5 = 0;
        while (n5 < 6) {
            n2 = 7 * (5 - n5);
            n = (int)(l2 >>> n2 & 0x7FL);
            if ((n -= n4) < 0) {
                n += 128;
            }
            nArray[n5] = n;
            ++n5;
        }
        char[] cArray = ((String)object).toCharArray();
        n2 = 0;
        while (n2 < cArray.length) {
            n = nArray[n2 % nArray.length];
            if (n == 0) break;
            cArray[n2] = (char)(cArray[n2] ^ n);
            ++n2;
        }
        _67.k[n3] = new String(cArray);
        return n3;
    }

    private static MethodHandle b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c == '\u00f5' || c == '\u00ef' || c == '\u00cf' || c == 'S') {
                field = _67.g(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c == '\u00f5' ? lookup.findGetter(clazz, string2, clazz2) : (c == '\u00ef' ? lookup.findSetter(clazz, string2, clazz2) : (c == '\u00cf' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = _67.h(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c == 'z' ? lookup.findVirtual(clazz, string3, methodType2) : (c == 'Y' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, Long.TYPE, Long.TYPE);
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static void b() {
        Object[] objectArray = j;
        j[0] = "\u000b\u001b\u0014tf\u0003\u000b\u001b\u0003(j\f\u0011P\u00036j\u0019\u0016!Wn=";
        objectArray[1] = ">\u001a[b\t7>\u001aL>\u00058$QL \u0005-# \u001e\u007fTg";
        objectArray[2] = Void.TYPE;
        _67.k[2] = "java/lang/Void";
        objectArray[3] = "47,\u000eRB47;R^M.|;L^X)\rk\u0011\u000f";
        objectArray[4] = "Lxe\u0011\u0017TLxrM\u001b[V3rS\u001bNQB%\fM";
        objectArray[5] = Boolean.TYPE;
        _67.k[5] = "java/lang/Boolean";
        objectArray[6] = "g]n[^~zHl\u001a[\"5@";
        objectArray[7] = Integer.TYPE;
        _67.k[7] = "java/lang/Integer";
        objectArray[8] = "\t>&/~4\u0014+$n{hY)";
        objectArray[9] = "/mDb!\u0001$bU-@\u000f/iQw";
        objectArray[10] = "*\u001b+\u0015*twS+%?ufA\"I\r&\"\u001fx%c hG$Le\u007fp_E";
        objectArray[11] = "\u0012fPH:5O.Px/4^<Y\u0014\u001dg\u001a`\u0005xs HgR\u0012u4M:>";
        objectArray[12] = "D 4mi?\u00039+n\u00150\u001f)>}BgA~f\u0011%d\u0010t*}x,\u0010";
        objectArray[13] = "sM \u000fih4T?\f\u0015g(D*\u001fB0v\u0014ss.50\u0012rJtrrL";
        objectArray[14] = "g\u0002\u001b\u000142:J\u001b1!3+X\u0012]\u0013`o\u0003D1\u007f'k[\u0004H.<'\u0007u";
        objectArray[15] = "f\"@N{D#$Z\u001e\u0014\u0012Zt@@hW;3Y_k";
        objectArray[16] = "\u0012 o\u0011C9\u0014\u007fw\t\"5Fd}\u0010N\u0007\u0016(%F\"kR$~\u0006[:Ih\"w";
        objectArray[17] = "}Q,\u0004\u0007\f{\u000e4\u001cf\u0000)\u0015>\u0005\n2~UnXVe\u007f\u0010b\u0001\u0017\u001c.\u000b.]f";
        objectArray[18] = "\u001a\u0010\u007f\u001bV\bGX\u007f+C\tVJvGqZ\u0013\u0013,+\u001d\u001d\u0016I`RL\u0006Z\u0015\u0011";
        objectArray[19] = "Jp~B86\u000f~bMF\u00170RMn\u001a\\Jp~B86\u000f~bM";
        objectArray[20] = "\u000b\u0019_R\r\t\rFGJl\u000eSLIX;^\b\u001a\u00104Q\u000b[JSZ\u000e\\[\u0011";
        objectArray[21] = "O`@\b\u001d=I?X\u0010|:\u00175V\u0002+jLe\u000enA?\u001f3L\u0000\u001eh\u001fh";
        Object[] objectArray2 = objectArray;
        objectArray[22] = ";\u0013\u000bh\u0015\u0015f[\u000bX\u0000\u0014wI\u000242D4\u0018TX^\u00007J\u0014!\u000f\u001b{\u0016e";
    }

    private static Object b(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n = objectArray.length - 2;
        long l2 = (Long)objectArray[n];
        long l3 = (Long)objectArray[++n];
        MethodHandle methodHandle = _67.b(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static CallSite c(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("dev/krypton/67" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static Field c(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static Method c(Class clazz, String string, Class clazz2, int n, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n) continue;
            for (int j = 0; j < n; ++j) {
                if (classArray2[j] != classArray[j]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static Method h(long l2, long l3) {
        int n = _67.e(l2, l3);
        Object object = j[n];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n2;
            String string;
            Class clazz3;
            block10: {
                String string2 = k[n];
                int n3 = string2.indexOf(8);
                clazz3 = _67.f(Long.parseLong(string2.substring(0, n3), 36), 0L);
                int n4 = string2.indexOf(8, ++n3);
                string = string2.substring(n3, n4);
                int n5 = -1;
                int n6 = n4;
                do {
                    ++n5;
                    ++n6;
                } while ((n6 = string2.indexOf(8, n6)) > -1);
                n2 = n5 - 1;
                classArray2 = new Class[n2];
                clazz2 = null;
                n6 = n4 + 1;
                for (int j = 0; j < n5; ++j) {
                    int n7 = string2.indexOf(8, n6);
                    clazz2 = _67.f(Long.parseLong(string2.substring(n6, n7), 36), 0L);
                    if (j < n2) {
                        classArray2[j] = clazz2;
                    }
                    n6 = n7 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = _67.c(clazz, string, clazz2, n2, classArray2)) != null) {
                        _67.j[n] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = _67.f(685941392827043L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int j = 0; j < classArray.length; ++j) {
                        Method method = _67.d(classArray[j], string, clazz2, n2, classArray2);
                        if (method == null) continue;
                        _67.j[n] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = _67.f(685941392827043L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n8 = 0;
            while (n8 < n2) {
                stringBuffer.append(classArray2[n8].getName());
                if (++n8 >= n2) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static Class f(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n = _67.e(l2, l3);
            object = j[n];
            try {
                if (!(object instanceof String)) break block2;
                _67.j[n] = clazz = Class.forName(k[n]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Method d(Class clazz, String string, Class clazz2, int n, Class[] classArray) {
        Method method = _67.c(clazz, string, clazz2, n, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int j = 0; j < classArray2.length; ++j) {
                method = _67.d(classArray2[j], string, clazz2, n, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Field d(Class clazz, String string, Class clazz2) {
        Field field = _67.c(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int j = 0; j < classArray.length; ++j) {
                field = _67.d(classArray[j], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static int a(int n, long l2) {
        int n2 = n ^ (int)(l2 & 0x7FFFL) ^ 0x896;
        if (e[n2] == null) {
            byte[] byArray;
            byte[] byArray2 = new byte[]{(byte)(l2 >>> 56), (byte)(l2 >>> 48), (byte)(l2 >>> 40), (byte)(l2 >>> 32), (byte)(l2 >>> 24), (byte)(l2 >>> 16), (byte)(l2 >>> 8), (byte)l2};
            long l3 = d[n2];
            byte[] byArray3 = new byte[]{(byte)(l3 >>> 56), (byte)(l3 >>> 48), (byte)(l3 >>> 40), (byte)(l3 >>> 32), (byte)(l3 >>> 24), (byte)(l3 >>> 16), (byte)(l3 >>> 8), (byte)l3};
            Long l4 = Thread.currentThread().threadId();
            Object[] objectArray = (Object[])f.get(l4);
            try {
                if (objectArray == null) {
                    objectArray = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
                    f.put(l4, objectArray);
                }
                DESKeySpec dESKeySpec = new DESKeySpec(byArray2);
                SecretKey secretKey = ((SecretKeyFactory)objectArray[1]).generateSecret(dESKeySpec);
                Cipher cipher = (Cipher)objectArray[0];
                cipher.init(2, (Key)secretKey, (IvParameterSpec)objectArray[2]);
                byArray = cipher.doFinal(byArray3);
            }
            catch (Exception exception) {
                throw new RuntimeException("dev/krypton/67", exception);
            }
            int n3 = (byArray[4] & 0xFF) << 24 | (byArray[5] & 0xFF) << 16 | (byArray[6] & 0xFF) << 8 | byArray[7] & 0xFF;
            _67.e[n2] = n3;
        }
        return e[n2];
    }

    private static CallSite a(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_1().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("dev/krypton/67" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static MatchException a(MatchException matchException) {
        return matchException;
    }

    private static int a(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, Object[] objectArray) {
        int n = (Integer)objectArray[0];
        long l2 = (Long)objectArray[1];
        int n2 = _67.a(n, l2);
        MethodHandle methodHandle = MethodHandles.constant(Integer.TYPE, n2);
        mutableCallSite.setTarget(MethodHandles.dropArguments(methodHandle, 0, Integer.TYPE, Long.TYPE));
        return n2;
    }

    private static Field g(long l2, long l3) {
        int n = _67.e(l2, l3);
        Object object = j[n];
        if (object instanceof String) {
            String string = k[n];
            int n2 = string.indexOf(8);
            Class clazz = _67.f(Long.parseLong(string.substring(0, n2), 36), 0L);
            int n3 = string.indexOf(8, ++n2);
            String string2 = string.substring(n2, n3);
            Class clazz2 = _67.f(Long.parseLong(string.substring(++n3), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = _67.c(clazz3, string2, clazz2)) != null) {
                    _67.j[n] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int j = 0; j < classArray.length; ++j) {
                        field = _67.d(classArray[j], string2, clazz2);
                        if (field == null) continue;
                        _67.j[n] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = _67.f(685941392827043L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(_67.class, "b", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_1() {
        try {
            return MethodHandles.lookup().findStatic(_67.class, "a", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

