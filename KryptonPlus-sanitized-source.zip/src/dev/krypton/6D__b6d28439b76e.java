/*
 * Decompiled with CFR 0.152.
 */
package dev.krypton;

import dev.krypton.l;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class _6D
extends Enum {
    public static final _6D Normal;
    public static final _6D Positive;
    public static final _6D Off;
    private final String cfr_renamed_5;
    private static final _6D[] cfr_renamed_6;
    private static final long a;
    private static final Object[] b;
    private static final String[] c;

    /*
     * WARNING - Possible parameter corruption
     * WARNING - void declaration
     */
    private _6D() {
        void var3_1;
        void cfr_renamed_27;
        void cfr_renamed_28;
        this.cfr_renamed_5 = var3_1;
    }

    /*
     * Unable to fully structure code
     */
    static {
        block11: {
            block10: {
                _6D.a = l.a(8048907540791662781L, -4944374674152646264L, MethodHandles.lookup().lookupClass()).a(60732789770489L);
                var9 = _6D.a ^ 99318661778986L;
                _6D.b = new Object[14];
                _6D.c = new String[14];
                _6D.a();
                var1_1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
                v0 = SecretKeyFactory.getInstance("DES");
                v1 = new byte[8];
                v2 = v1;
                v1[0] = (byte)(var9 >>> 56);
                for (var2_2 = 1; var2_2 < 8; ++var2_2) {
                    v2 = v2;
                    v2[var2_2] = (byte)(var9 << var2_2 * 8 >>> 56);
                }
                var1_1.init(2, (Key)v0.generateSecret(new DESKeySpec(v2)), new IvParameterSpec(new byte[8]));
                var0_3 = new String[6];
                var6_4 = 0;
                var5_5 = ">\u00ea\u00b3L\r1\u007f8\u0010)\u00f0\u0013\u00ea\u00f5\u000b\u00915\u00af\u00e7\u001a\u00a6\u00f9\u00a3H\u00c1\b\u009a\u00cb\u009fH\u008dt\u0015\u0004\b\u009a\u00cb\u009fH\u008dt\u0015\u0004";
                var7_6 = ">\u00ea\u00b3L\r1\u007f8\u0010)\u00f0\u0013\u00ea\u00f5\u000b\u00915\u00af\u00e7\u001a\u00a6\u00f9\u00a3H\u00c1\b\u009a\u00cb\u009fH\u008dt\u0015\u0004\b\u009a\u00cb\u009fH\u008dt\u0015\u0004".length();
                var4_7 = 8;
                var3_8 = -1;
lbl22:
                // 2 sources

                while (true) {
                    v3 = ++var3_8;
                    v4 = var5_5.substring(v3, v3 + var4_7);
                    v5 = -1;
                    break block10;
                    break;
                }
lbl27:
                // 1 sources

                while (true) {
                    var0_3[var6_4++] = _6D.a(var8_9).intern();
                    if ((var3_8 += var4_7) < var7_6) {
                        var4_7 = var5_5.charAt(var3_8);
                        ** continue;
                    }
                    var5_5 = ">\u00ea\u00b3L\r1\u007f8\u0010)\u00f0\u0013\u00ea\u00f5\u000b\u00915\u00af\u00e7\u001a\u00a6\u00f9\u00a3H\u00c1";
                    var7_6 = ">\u00ea\u00b3L\r1\u007f8\u0010)\u00f0\u0013\u00ea\u00f5\u000b\u00915\u00af\u00e7\u001a\u00a6\u00f9\u00a3H\u00c1".length();
                    var4_7 = 8;
                    var3_8 = -1;
lbl36:
                    // 2 sources

                    while (true) {
                        v6 = ++var3_8;
                        v4 = var5_5.substring(v6, v6 + var4_7);
                        v5 = 0;
                        break block10;
                        break;
                    }
                    break;
                }
lbl41:
                // 1 sources

                while (true) {
                    var0_3[var6_4++] = _6D.a(var8_9).intern();
                    if ((var3_8 += var4_7) < var7_6) {
                        var4_7 = var5_5.charAt(var3_8);
                        ** continue;
                    }
                    break block11;
                    break;
                }
            }
            var8_9 = var1_1.doFinal(v4.getBytes("ISO-8859-1"));
            switch (v5) {
                default: {
                    ** continue;
                }
                ** case 0:
lbl53:
                // 1 sources

                ** continue;
            }
        }
        _6D.Normal = new _6D(var0_3[2], 0, var0_3[3]);
        _6D.Positive = new _6D(var0_3[1], 1, var0_3[5]);
        _6D.Off = new _6D(var0_3[4], 2, var0_3[0]);
        _6D.cfr_renamed_6 = _6D.a("R", (long)8470929646724357510L, (long)var9);
    }

    public String toString() {
        long l2 = a ^ 0x64DABDDC73A9L;
        return _6D.a("H", (Object)((Object)this), 580632996099913319L, (long)l2);
    }

    public static _6D[] values() {
        long l2 = a ^ 0xAF852824FDEL;
        return (_6D[])((Enum)((Object)_6D.a("\u00f8", 3781459986297285341L, (long)l2))).clone();
    }

    public static _6D valueOf(String string) {
        long l2 = a ^ 0x4D1711DEF59L;
        return (_6D)((Object)_6D.a("R", _6D.class, (Object)string, -7711182388293957993L, (long)l2));
    }

    private static Class b(long l2, long l3) {
        Object object;
        Class<?> clazz;
        block2: {
            clazz = null;
            int n = _6D.a(l2, l3);
            object = b[n];
            try {
                if (!(object instanceof String)) break block2;
                _6D.b[n] = clazz = Class.forName(c[n]);
            }
            catch (Exception exception) {
                throw new RuntimeException(exception.toString());
            }
        }
        clazz = (Class<?>)object;
        return clazz;
    }

    private static Field b(Class clazz, String string, Class clazz2) {
        Field field = _6D.a(clazz, string, clazz2);
        if (field != null) {
            return field;
        }
        Class<?>[] classArray = clazz.getInterfaces();
        if (classArray != null) {
            for (int j = 0; j < classArray.length; ++j) {
                field = _6D.b(classArray[j], string, clazz2);
                if (field == null) continue;
                return field;
            }
        }
        return null;
    }

    private static Method b(Class clazz, String string, Class clazz2, int n, Class[] classArray) {
        Method method = _6D.a(clazz, string, clazz2, n, classArray);
        if (method != null) {
            return method;
        }
        Class<?>[] classArray2 = clazz.getInterfaces();
        if (classArray2 != null) {
            for (int j = 0; j < classArray2.length; ++j) {
                method = _6D.b(classArray2[j], string, clazz2, n, classArray);
                if (method == null) continue;
                return method;
            }
        }
        return null;
    }

    private static Field c(long l2, long l3) {
        int n = _6D.a(l2, l3);
        Object object = b[n];
        if (object instanceof String) {
            String string = c[n];
            int n2 = string.indexOf(8);
            Class clazz = _6D.b(Long.parseLong(string.substring(0, n2), 36), 0L);
            int n3 = string.indexOf(8, ++n2);
            String string2 = string.substring(n2, n3);
            Class clazz2 = _6D.b(Long.parseLong(string.substring(++n3), 36), 0L);
            Class clazz3 = clazz;
            while (true) {
                Field field;
                if ((field = _6D.a(clazz3, string2, clazz2)) != null) {
                    _6D.b[n] = field;
                    return field;
                }
                Class<?>[] classArray = clazz3.getInterfaces();
                if (classArray != null) {
                    for (int j = 0; j < classArray.length; ++j) {
                        field = _6D.b(classArray[j], string2, clazz2);
                        if (field == null) continue;
                        _6D.b[n] = field;
                        return field;
                    }
                }
                if (clazz3.getName().equals("java.lang.Object")) break;
                if ((clazz3 = clazz3.getSuperclass()) != null) continue;
                clazz3 = _6D.b(447528690225591L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchFieldException in ").append(clazz.getName()).append(' ').append(clazz2.getName()).append(' ').append(string2);
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Field)object;
    }

    private static Method d(long l2, long l3) {
        int n = _6D.a(l2, l3);
        Object object = b[n];
        if (object instanceof String) {
            Class<?>[] classArray;
            Class clazz;
            Class clazz2;
            Class[] classArray2;
            int n2;
            String string;
            Class clazz3;
            block10: {
                String string2 = c[n];
                int n3 = string2.indexOf(8);
                clazz3 = _6D.b(Long.parseLong(string2.substring(0, n3), 36), 0L);
                int n4 = string2.indexOf(8, ++n3);
                string = string2.substring(n3, n4);
                int n5 = -1;
                int n6 = n4;
                do {
                    ++n5;
                    ++n6;
                } while ((n6 = string2.indexOf(8, n6)) > -1);
                n2 = n5 - 1;
                classArray2 = new Class[n2];
                clazz2 = null;
                n6 = n4 + 1;
                for (int j = 0; j < n5; ++j) {
                    int n7 = string2.indexOf(8, n6);
                    clazz2 = _6D.b(Long.parseLong(string2.substring(n6, n7), 36), 0L);
                    if (j < n2) {
                        classArray2[j] = clazz2;
                    }
                    n6 = n7 + 1;
                }
                clazz = clazz3;
                do {
                    if ((classArray = _6D.a(clazz, string, clazz2, n2, classArray2)) != null) {
                        _6D.b[n] = classArray;
                        return classArray;
                    }
                    if (clazz.getName().equals("java.lang.Object")) break block10;
                } while ((clazz = clazz.getSuperclass()) != null);
                clazz = _6D.b(447528690225591L, 0L);
            }
            clazz = clazz3;
            while (true) {
                if ((classArray = clazz.getInterfaces()) != null) {
                    for (int j = 0; j < classArray.length; ++j) {
                        Method method = _6D.b(classArray[j], string, clazz2, n2, classArray2);
                        if (method == null) continue;
                        _6D.b[n] = method;
                        return method;
                    }
                }
                if (clazz.getName().equals("java.lang.Object")) break;
                if ((clazz = clazz.getSuperclass()) != null) continue;
                clazz = _6D.b(447528690225591L, 0L);
            }
            StringBuffer stringBuffer = new StringBuffer();
            stringBuffer.append("NoSuchMethodException in ").append(clazz3.getName()).append(' ').append(clazz2.getName()).append(' ').append(string).append('(');
            int n8 = 0;
            while (n8 < n2) {
                stringBuffer.append(classArray2[n8].getName());
                if (++n8 >= n2) continue;
                stringBuffer.append(", ");
            }
            stringBuffer.append(')');
            throw new RuntimeException(stringBuffer.toString());
        }
        return (Method)object;
    }

    private static Method a(Class clazz, String string, Class clazz2, int n, Class[] classArray) {
        block0: for (Method method : clazz.getDeclaredMethods()) {
            Class<?>[] classArray2;
            if (!method.getName().equals(string) || method.getReturnType() != clazz2 || (classArray2 = method.getParameterTypes()).length != n) continue;
            for (int j = 0; j < n; ++j) {
                if (classArray2[j] != classArray[j]) continue block0;
            }
            return method;
        }
        return null;
    }

    private static CallSite a(MethodHandles.Lookup lookup, String string, MethodType methodType) {
        MutableCallSite mutableCallSite = new MutableCallSite(methodType);
        try {
            mutableCallSite.setTarget(MethodHandles.explicitCastArguments(MethodHandles.insertArguments(cfr_ldc_0().asCollector(Object[].class, methodType.parameterCount()), 0, lookup, mutableCallSite, string, methodType), methodType));
        }
        catch (Exception exception) {
            throw new RuntimeException("dev/krypton/6D" + " : " + string + " : " + methodType.toString(), exception);
        }
        return mutableCallSite;
    }

    private static MethodHandle a(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, long l2, long l3) {
        char c = string.charAt(0);
        MethodHandle methodHandle = null;
        Field field = null;
        Method method = null;
        try {
            if (c == 'H' || c == '\u00e2' || c == '\u00f8' || c == '\u00ba') {
                field = _6D.c(l2, l3);
                Class<?> clazz = field.getDeclaringClass();
                String string2 = field.getName();
                Class<?> clazz2 = field.getType();
                methodHandle = c == 'H' ? lookup.findGetter(clazz, string2, clazz2) : (c == '\u00e2' ? lookup.findSetter(clazz, string2, clazz2) : (c == '\u00f8' ? lookup.findStaticGetter(clazz, string2, clazz2) : lookup.findStaticSetter(clazz, string2, clazz2)));
            } else {
                method = _6D.d(l2, l3);
                Class<?> clazz = method.getDeclaringClass();
                String string3 = method.getName();
                MethodType methodType2 = MethodType.methodType(method.getReturnType(), method.getParameterTypes());
                methodHandle = c == 'B' ? lookup.findVirtual(clazz, string3, methodType2) : (c == 'R' ? lookup.findStatic(clazz, string3, methodType2) : lookup.findSpecial(clazz, string3, methodType2, clazz));
            }
            return MethodHandles.dropArguments(methodHandle, methodType.parameterCount() - 2, Long.TYPE, Long.TYPE);
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(exception.getClass().getName()).append(" : ").append(field != null ? field.toString() : (method != null ? method.toString() : " null ")).append(" : ").append(exception.toString());
            throw new RuntimeException(stringBuilder.toString());
        }
    }

    private static Object a(MethodHandles.Lookup lookup, MutableCallSite mutableCallSite, String string, MethodType methodType, Object[] objectArray) {
        int n = objectArray.length - 2;
        long l2 = (Long)objectArray[n];
        long l3 = (Long)objectArray[++n];
        MethodHandle methodHandle = _6D.a(lookup, mutableCallSite, string, methodType, l2, l3);
        mutableCallSite.setTarget(MethodHandles.explicitCastArguments(methodHandle, methodType));
        return methodHandle.asSpreader(Object[].class, objectArray.length).invoke(objectArray);
    }

    private static int a(long l2, long l3) {
        int n;
        int n2;
        int n3 = (int)((l2 ^= l3 << 48 | l3) >>> 46);
        if (c[n3] != null) {
            return n3;
        }
        Object object = b[n3];
        if (!(object instanceof String)) {
            return n3;
        }
        int n4 = 0;
        n4 = switch ((int)(l2 >>> 42 & 0x3FL)) {
            case 0 -> 42;
            case 1 -> 62;
            case 2 -> 1;
            case 3 -> 41;
            case 4 -> 24;
            case 5 -> 31;
            case 6 -> 4;
            case 7 -> 44;
            case 8 -> 29;
            case 9 -> 8;
            case 10 -> 10;
            case 11 -> 5;
            case 12 -> 17;
            case 13 -> 54;
            case 14 -> 2;
            case 15 -> 52;
            case 16 -> 59;
            case 17 -> 30;
            case 18 -> 55;
            case 19 -> 9;
            case 20 -> 49;
            case 21 -> 48;
            case 22 -> 26;
            case 23 -> 22;
            case 24 -> 27;
            case 25 -> 46;
            case 26 -> 61;
            case 27 -> 25;
            case 28 -> 50;
            case 29 -> 40;
            case 30 -> 18;
            case 31 -> 63;
            case 32 -> 38;
            case 33 -> 37;
            case 34 -> 19;
            case 35 -> 15;
            case 36 -> 56;
            case 37 -> 14;
            case 38 -> 47;
            case 39 -> 39;
            case 40 -> 12;
            case 41 -> 53;
            case 42 -> 6;
            case 43 -> 60;
            case 44 -> 57;
            case 45 -> 13;
            case 46 -> 45;
            case 47 -> 28;
            case 48 -> 20;
            case 49 -> 7;
            case 50 -> 3;
            case 51 -> 0;
            case 52 -> 51;
            case 53 -> 33;
            case 54 -> 43;
            case 55 -> 36;
            case 56 -> 16;
            case 57 -> 32;
            case 58 -> 23;
            case 59 -> 21;
            case 60 -> 11;
            case 61 -> 34;
            case 62 -> 58;
            default -> 35;
        };
        int[] nArray = new int[6];
        int n5 = 0;
        while (n5 < 6) {
            n2 = 7 * (5 - n5);
            n = (int)(l2 >>> n2 & 0x7FL);
            if ((n -= n4) < 0) {
                n += 128;
            }
            nArray[n5] = n;
            ++n5;
        }
        char[] cArray = ((String)object).toCharArray();
        n2 = 0;
        while (n2 < cArray.length) {
            n = nArray[n2 % nArray.length];
            if (n == 0) break;
            cArray[n2] = (char)(cArray[n2] ^ n);
            ++n2;
        }
        _6D.c[n3] = new String(cArray);
        return n3;
    }

    private static void a() {
        Object[] objectArray = b;
        b[0] = " ?&!UJ=*$`P\u0016r\u001e";
        objectArray[1] = "\u000fgY\u0018\u0005\u0001\u0004hHWx\u0019\u0017oA\u001e";
        objectArray[2] = "\u000fPi\u001aP\u0005?nt\u000fRD:2;;\u001d";
        objectArray[3] = "jp;G{HZN&Ry\t_\u0012if6";
        objectArray[4] = "u\u0003*HHz~\f;\u0007#xj\u000f";
        objectArray[5] = "d\u007f1H9\u0019op \u0007T\u0019om4";
        objectArray[6] = "89`\u0001;E36qNZK8=u\u0014";
        objectArray[7] = "\u0000Lx@B\u0000T\\)0DiFU:[\u0000\u0003\u0004Mq";
        objectArray[8] = " qQH\u000bEta\u00008\u000f,#w\u001aTZ^su\u0018I";
        objectArray[9] = "\u000e?ip\u0012\u001aZ/8\u0000k\u0014M10d-J\\d)?D\u001eL5";
        objectArray[10] = "\u000e%]\u00149mZ5\fd^cL/\u0011\u0005xi7w\u0006Tv;^#\u0016\u0005";
        objectArray[11] = "H44Sw\u001b\u001c$e#xrK2\u007fO&\u0000\u001b0}RH";
        objectArray[12] = "p(\u001e^by4k\u0018\u0007\r?\"w\u0007TJ/K(\u0019^k-:n\u0005@1A4a\bRp+vyC96z/t\u0015\u0001r9)-z";
        Object[] objectArray2 = objectArray;
        objectArray[13] = "\tT\u007f\u0007\u0001\u001f]D.wy\u0018^?v\u001c\u000e\u0006\u000fV\"\f_";
    }

    private static String a(byte[] byArray) {
        int n = 0;
        int n2 = byArray.length;
        char[] cArray = new char[n2];
        for (int j = 0; j < n2; ++j) {
            char c;
            int n3 = 0xFF & byArray[j];
            if (n3 < 192) {
                cArray[n++] = (char)n3;
                continue;
            }
            if (n3 < 224) {
                c = (char)((char)(n3 & 0x1F) << 6);
                n3 = byArray[++j];
                c = (char)(c | (char)(n3 & 0x3F));
                cArray[n++] = c;
                continue;
            }
            if (j >= n2 - 2) continue;
            c = (char)((char)(n3 & 0xF) << 12);
            n3 = byArray[++j];
            c = (char)(c | (char)(n3 & 0x3F) << 6);
            n3 = byArray[++j];
            c = (char)(c | (char)(n3 & 0x3F));
            cArray[n++] = c;
        }
        return new String(cArray, 0, n);
    }

    private static Field a(Class clazz, String string, Class clazz2) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!field.getName().equals(string) || field.getType() != clazz2) continue;
            return field;
        }
        return null;
    }

    private static _6D[] cfr_renamed_0() {
        long l2 = a ^ 0x399D387CACCFL;
        return new _6D[]{_6D.a("\u00f8", -2924232573738014881L, (long)l2), _6D.a("\u00f8", -2924001315844105869L, (long)l2), _6D.a("\u00f8", -2924497072094387002L, (long)l2)};
    }

    /*
     * Works around MethodHandle LDC.
     */
    static MethodHandle cfr_ldc_0() {
        try {
            return MethodHandles.lookup().findStatic(_6D.class, "a", MethodType.fromMethodDescriptorString("(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;", null));
        }
        catch (NoSuchMethodException | IllegalAccessException except) {
            throw new IllegalArgumentException(except);
        }
    }
}

